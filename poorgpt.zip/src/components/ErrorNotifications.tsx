import { useWallet } from '../contexts/WalletContext';
import { useAuth } from '../contexts/AuthContext';
import { AnimatePresence, motion } from 'motion/react';
import { X, AlertTriangle } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function ErrorNotifications() {
  const { error: walletError } = useWallet();
  const { error: authError } = useAuth();
  
  const [activeError, setActiveError] = useState<string | null>(null);

  useEffect(() => {
    if (walletError) setActiveError(walletError);
    else if (authError) setActiveError(authError);
    
    if (walletError || authError) {
      const timer = setTimeout(() => {
        setActiveError(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [walletError, authError]);

  return (
    <div className="fixed bottom-4 right-4 z-[200] flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {activeError && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
            className="bg-card-bg border border-white/5 border-l-4 border-l-red-500 shadow-2xl p-4 w-[320px] pointer-events-auto flex gap-3 items-start"
          >
            <AlertTriangle className="text-red-500 shrink-0 mt-0.5" size={20} />
            <div className="flex-grow">
              <h4 className="font-bold uppercase tracking-tighter text-sm mb-1 text-white">System Error</h4>
              <p className="text-xs text-white/70 leading-relaxed font-mono">{activeError}</p>
            </div>
            <button 
              onClick={() => setActiveError(null)}
              className="opacity-50 hover:opacity-100 hover:text-white transition-colors cursor-pointer text-white"
            >
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
