import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-dark-bg text-white py-12 px-4 md:px-10 border-t border-white/10">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="label-caps !opacity-40">© 2026 poorgpt.ph / Burn After Reading</div>
        
        <div className="flex gap-8 items-center flex-wrap justify-center">
          <div className="flex gap-4 label-caps !opacity-60">
            <Link to="/privacy" className="hover:text-accent hover:!opacity-100 transition-colors">Privacy</Link>
            <Link to="/terms" className="hover:text-accent hover:!opacity-100 transition-colors">Terms</Link>
          </div>
          <div className="label-caps !opacity-100 flex items-center gap-2 border-l border-white/20 pl-8">
            <div className="w-2 h-2 bg-accent animate-pulse" />
            Contract: 0x82...f92a
          </div>
          <div className="label-caps !opacity-100 border-l border-white/20 pl-8">
            Verified on PoorScan
          </div>
        </div>
      </div>
    </footer>
  );
}
