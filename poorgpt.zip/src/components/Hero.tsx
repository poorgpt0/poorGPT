import { motion } from 'motion/react';

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-dark-bg py-20 px-4 md:px-10 border-b border-white/5">
      <div className="max-w-7xl mx-auto relative min-h-[70vh] flex flex-col justify-center">
        {/* Massive Background text */}
        <div className="huge-text absolute top-0 left-0 w-full opacity-5 select-none pointer-events-none translate-y-[-20%] md:translate-y-[-10%]">
          COLLECTION
        </div>

        <div className="relative z-10 flex flex-col md:flex-row items-end justify-between gap-12">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex-grow"
          >
            <h1 className="huge-text mb-12 glitch" data-text="DAPPS">
              POOR<br />
              <span className="text-accent">DAPPS</span>
            </h1>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="max-w-xs text-right"
          >
            <p className="text-lg leading-tight opacity-80 mb-8">
              The world's first NFT gallery curated by a broke language model. No GPUs, no electricity, just vibes and bad prompts.
            </p>
            <div className="flex justify-end gap-4 overflow-hidden py-2 border-y border-white/10 uppercase font-bold text-[10px] tracking-widest text-accent whitespace-nowrap">
               <motion.div
                 animate={{ x: [0, -100] }}
                 transition={{ repeat: Infinity, duration: 5, ease: "linear" }}
               >
                 SYSTEM_STATUS: NOMINAL // TOKEN_COUNT: 0 // SYSTEM_STATUS: NOMINAL // TOKEN_COUNT: 0 
               </motion.div>
            </div>
          </motion.div>
        </div>

        {/* Hero image overlay logic simplified for bold theme */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-4">
           {[1, 2, 3, 4].map((i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0, scale: 0.8 }}
               animate={{ opacity: 1, scale: 1 }}
               transition={{ delay: 0.2 * i }}
               className="aspect-[4/5] bg-card-bg border border-white/5 overflow-hidden group"
             >
               <img 
                 src={`https://picsum.photos/seed/hero-${i}/600/800?grayscale`} 
                 alt={`Gallery ${i}`} 
                 className="w-full h-full object-cover opacity-50 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
                 referrerPolicy="no-referrer"
               />
             </motion.div>
           ))}
        </div>
      </div>
    </section>
  );
}
