import { motion } from 'motion/react';
import { NFT } from '../types';
import { ExternalLink, Tag } from 'lucide-react';

interface NFTCardProps {
  nft: NFT;
  onClick: (nft: NFT) => void;
}

export default function NFTCard({ nft, onClick }: NFTCardProps) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="group relative bg-card-bg border border-border-subtle hover:border-accent transition-all cursor-pointer overflow-hidden flex flex-col p-4 gap-4"
      onClick={() => onClick(nft)}
    >
      <div className="relative aspect-square overflow-hidden bg-neutral-900 border border-white/5">
        <img 
          src={nft.image} 
          alt={nft.name} 
          className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-accent/10 backdrop-blur-sm">
           <span className="font-black text-xs text-black bg-accent px-4 py-2 uppercase tracking-tighter">View Asset</span>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex justify-between items-start">
          <div className="flex flex-col gap-1">
            <div className="label-caps flex items-center gap-2">
              <span className="bg-white/10 px-1 py-0.5 text-accent">{nft.tag}</span>
              <span>Item #{nft.id.padStart(3, '0')}</span>
            </div>
            <h3 className="font-bold text-lg uppercase leading-none truncate max-w-[150px]">{nft.name}</h3>
          </div>
          <div className="text-right">
            <div className="label-caps !opacity-100 text-accent">Value</div>
            <div className="font-black text-accent">{nft.price}</div>
          </div>
        </div>
      </div>
      
      {/* Accent corner */}
      <div className="absolute top-0 right-0 w-2 h-2 bg-white/10 group-hover:bg-accent transition-colors" />
    </motion.div>
  );
}
