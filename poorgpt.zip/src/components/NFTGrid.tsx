import { useState } from 'react';
import { NFTS } from '../constants';
import { NFT } from '../types';
import NFTCard from './NFTCard';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink, ShieldCheck, Zap, Ghost } from 'lucide-react';

export default function NFTGrid() {
  const [selectedNFT, setSelectedNFT] = useState<NFT | null>(null);
  const [activeFilter, setActiveFilter] = useState('ALL');

  const displayedNFTs = activeFilter === 'ALL' ? NFTS : NFTS.filter(nft => nft.tag === activeFilter);

  return (
    <section className="py-24 px-4 md:px-10 bg-dark-bg border-b border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
          <div>
            <div className="label-caps !opacity-100 text-accent mb-2">Live Marketplace</div>
            <h2 className="huge-text !text-7xl !leading-none">Recent Collections</h2>
          </div>
          <div className="flex flex-wrap gap-4 border-b border-white/10 pb-4">
             {['ALL', 'GLITCH', 'SYSTEM', 'AI-FAIL'].map(filter => (
               <button 
                 key={filter} 
                 onClick={() => setActiveFilter(filter)}
                 className={`label-caps !opacity-40 hover:!opacity-100 hover:text-accent transition-all cursor-pointer ${activeFilter === filter ? '!opacity-100 text-accent' : ''}`}
               >
                 {filter}
               </button>
             ))}
          </div>
        </div>

        {displayedNFTs.length === 0 ? (
          <div className="py-32 flex flex-col items-center justify-center text-center border border-dashed border-white/20 bg-white/5 relative overflow-hidden group">
            <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <Ghost size={64} className="text-accent mb-6 opacity-80 group-hover:scale-110 transition-transform" />
            <h3 className="text-4xl md:text-5xl font-black uppercase tracking-tighter mb-4">No Assets Found</h3>
            <p className="text-lg opacity-60 font-mono uppercase">The latent space is empty here.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayedNFTs.map((nft, i) => (
              <motion.div
                key={nft.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
              >
                <NFTCard nft={nft} onClick={(nft) => setSelectedNFT(nft)} />
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Modal Detail View */}
      <AnimatePresence>
        {selectedNFT && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12 bg-black/98 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card-bg border border-white/10 w-full max-w-6xl max-h-full overflow-y-auto flex flex-col md:grid md:grid-cols-2 relative"
            >
              <button 
                onClick={() => setSelectedNFT(null)}
                className="absolute top-8 right-8 z-10 text-white/50 hover:text-accent transition-all cursor-pointer"
              >
                <X size={40} strokeWidth={1} />
              </button>

              <div className="bg-black flex items-center justify-center border-b md:border-b-0 md:border-r border-white/10 p-12">
                <div className="relative group">
                  <img 
                    src={selectedNFT.image} 
                    alt={selectedNFT.name} 
                    className="max-h-[60vh] md:max-h-[70vh] w-auto border border-white/5 shadow-[0_0_100px_rgba(223,255,0,0.05)]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-4 -right-4 bg-accent text-black p-4 font-black text-xl uppercase tracking-tighter">
                    {selectedNFT.price}
                  </div>
                </div>
              </div>

              <div className="p-8 md:p-16 flex flex-col gap-10 justify-center">
                <div>
                  <div className="label-caps !opacity-100 text-accent mb-4">NFT ASSET // AUTHENTICATED ERROR</div>
                  <h2 className="huge-text !text-6xl !leading-none mb-6">{selectedNFT.name}</h2>
                  <div className="flex gap-6">
                    <div className="flex items-center gap-2 label-caps">
                      <Zap size={14} className="text-accent" />
                      Poor Network
                    </div>
                    <div className="flex items-center gap-2 label-caps">
                      <ShieldCheck size={14} className="text-accent" />
                      Unverified Hallucination
                    </div>
                  </div>
                </div>

                <p className="text-xl leading-relaxed opacity-70 border-l-2 border-accent pl-8 py-2">
                  {selectedNFT.description}
                </p>

                <div className="flex flex-col gap-8 py-10 border-y border-white/5">
                  <div className="grid grid-cols-2 gap-8">
                    <div>
                      <span className="label-caps block mb-2">Architect</span>
                      <span className="font-bold truncate block text-lg">{selectedNFT.creator}</span>
                    </div>
                    <div>
                      <span className="label-caps block mb-2">Current Holder</span>
                      <span className="font-bold truncate block text-lg">{selectedNFT.owner}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex flex-col gap-6">
                  <button className="w-full bg-accent text-black py-8 font-black text-3xl uppercase hover:scale-[1.02] active:scale-98 transition-all cursor-pointer">
                    Acquire Asset
                  </button>
                  <a href="#" className="flex items-center justify-center gap-2 label-caps !opacity-100 hover:text-accent transition-colors">
                    View Metadata on Explorer <ExternalLink size={14} />
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
