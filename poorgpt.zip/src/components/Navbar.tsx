import { motion } from 'motion/react';
import { Wallet, Menu, X, User } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { useAuth } from '../contexts/AuthContext';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { address, connect, disconnect, error: walletError } = useWallet();
  const { user, signInWithGoogle, logout, error: authError } = useAuth();

  return (
    <nav className="sticky top-0 z-50 bg-dark-bg border-b border-white/10 px-4 md:px-10 py-10">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/">
          <motion.div 
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="flex flex-col"
          >
            <div className="label-caps !opacity-60">Decentralized Gallery</div>
            <div className="text-3xl font-black tracking-tighter flex items-end">
              poorgpt<span className="text-accent underline underline-offset-4 decoration-accent">.ph</span>
            </div>
          </motion.div>
        </Link>

        {/* Info Stats (Desktop) */}
        <div className="hidden lg:flex gap-12 font-bold uppercase tracking-tight">
          <div className="text-right">
            <div className="label-caps">Floor Price</div>
            <div className="text-lg">0.00004 ETH</div>
          </div>
          <div className="text-right border-x border-white/10 px-12">
            <div className="label-caps">Volume</div>
            <div className="text-lg">1.2 ETH</div>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-6 font-bold uppercase tracking-tighter">
          <Link to="/gallery" className="hover:text-accent transition-colors">Gallery</Link>
          <Link to="/drops" className="hover:text-accent transition-colors">Drops</Link>
          <Link to="/stats" className="hover:text-accent transition-colors hidden xl:block">Stats</Link>
          
          <div className="flex items-center gap-4 border-l border-white/10 pl-6 ml-2 relative">
            {/* Google Auth Status */}
            {user ? (
              <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-sm border border-white/10">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="User avatar" className="w-6 h-6 rounded-full" />
                ) : (
                  <User size={16} />
                )}
                <span className="text-xs truncate max-w-[100px]">{user.displayName || user.email}</span>
                <button onClick={logout} className="ml-2 label-caps hover:text-red-500 cursor-pointer">Out</button>
              </div>
            ) : (
              <motion.button 
                onClick={signInWithGoogle}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-2 bg-white/10 text-white px-4 py-3 text-xs font-black uppercase cursor-pointer hover:bg-white/20 transition-colors"
              >
                <span>Google</span>
              </motion.button>
            )}

            {/* Wallet Status */}
            {address ? (
              <div className="flex items-center gap-4 bg-accent/10 px-4 py-2 border border-accent/20">
                <Link to="/profile" className="flex items-center gap-2 text-accent hover:text-white transition-colors">
                  <Wallet size={16} />
                  <span className="text-xs">{address}</span>
                </Link>
                <button onClick={disconnect} className="label-caps hover:text-red-500 cursor-pointer">Disconnect</button>
              </div>
            ) : (
                <div className="flex gap-2">
                  <motion.button 
                    onClick={() => connect('metamask')}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 bg-white text-black px-4 py-3 text-[10px] font-black uppercase cursor-pointer"
                  >
                    <img src="https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg" className="w-4 h-4" alt="MetaMask" />
                    <span>MetaMask</span>
                  </motion.button>
                  <motion.button 
                    onClick={() => connect('trustwallet')}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 bg-blue-600 text-white px-4 py-3 text-[10px] font-black uppercase cursor-pointer border border-blue-500"
                  >
                     <Wallet size={14} />
                    <span>TrustWallet</span>
                  </motion.button>
                </div>
            )}


          </div>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-full left-0 w-full bg-dark-bg border-b border-white/10 flex flex-col p-10 gap-6 font-bold text-2xl uppercase tracking-tighter shadow-2xl z-50"
        >
          <Link to="/gallery" className="hover:text-accent" onClick={() => setIsOpen(false)}>Gallery</Link>
          <Link to="/drops" className="hover:text-accent" onClick={() => setIsOpen(false)}>Drops</Link>
          <Link to="/stats" className="hover:text-accent" onClick={() => setIsOpen(false)}>Stats</Link>
          
          {address && (
            <Link to="/profile" className="text-accent hover:text-white" onClick={() => setIsOpen(false)}>Profile</Link>
          )}

          <div className="h-px bg-white/10 my-4" />
          
          <div className="flex flex-col gap-4 text-base">
            <div className="label-caps !opacity-60 mb-2">Web2 Account</div>
            {user ? (
               <div className="flex flex-col gap-4 bg-white/5 p-4 border border-white/10">
                 <div className="flex items-center gap-3">
                   {user.photoURL && <img src={user.photoURL} className="w-8 h-8 rounded-full" />}
                   <span className="truncate">{user.email}</span>
                 </div>
                 <button onClick={() => { logout(); setIsOpen(false); }} className="bg-red-900/50 text-red-500 py-3 uppercase text-sm border border-red-900/50 active:scale-95 transition-all">Sign Out</button>
               </div>
            ) : (
               <button onClick={() => { signInWithGoogle(); setIsOpen(false); }} className="bg-white/10 text-white py-4 font-black uppercase active:scale-95 transition-all border border-white/20">
                 Sign In With Google
               </button>
            )}

            <div className="label-caps !opacity-60 mb-2 mt-4">Web3 Wallet</div>
            {address ? (
              <button onClick={() => { disconnect(); setIsOpen(false); }} className="flex items-center justify-center gap-2 bg-accent/20 text-accent border border-accent/30 px-4 py-4 font-black uppercase active:scale-95 transition-all w-full cursor-pointer">
                <span>Disconnect Wallet ({address.substring(0,6)}...)</span>
              </button>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => { connect('metamask'); setIsOpen(false); }} className="flex flex-col items-center justify-center gap-2 bg-white text-black px-2 py-4 font-black uppercase active:scale-95 transition-all w-full cursor-pointer text-xs">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg" className="w-6 h-6" alt="MetaMask" />
                  <span>MetaMask</span>
                </button>
                <button onClick={() => { connect('trustwallet'); setIsOpen(false); }} className="flex flex-col items-center justify-center gap-2 bg-blue-600 text-white px-2 py-4 font-black uppercase active:scale-95 transition-all w-full cursor-pointer text-xs border border-blue-500">
                  <Wallet size={24} />
                  <span>TrustWallet</span>
                </button>
              </div>
            )}


          </div>
        </motion.div>
      )}
    </nav>
  );
}
