import { NFT } from './types';

export const NFTS: NFT[] = [
  {
    id: '1',
    name: 'STAGGERED REALITY [01]',
    description: 'A glimpse into the mind of a low-bandwidth AI trying to render a sunset on a 486 processor.',
    image: 'https://picsum.photos/seed/poorgpt1/800/800',
    price: '0.001 ETH',
    owner: '0xPoor...1337',
    creator: 'PoorGPT_v1',
    tag: 'GLITCH'
  },
  {
    id: '2',
    name: 'DIGITAL DEBRIS #44',
    description: 'Found data packets from the early 2000s, polished and mounted on a virtual pedestal.',
    image: 'https://picsum.photos/seed/poorgpt2/800/800',
    price: '0.042 ETH',
    owner: '0xRich...8888',
    creator: 'GarbageMan',
    tag: 'RECYCLED'
  },
  {
    id: '3',
    name: 'SYSTEM FAILURE ERROR',
    description: 'When the GPT hallucination becomes the art itself. Pure, unadulterated nonsense.',
    image: 'https://picsum.photos/seed/poorgpt3/800/1000',
    price: '1.5 ETH',
    owner: '0xDead...BEEF',
    creator: 'PoorGPT_v2',
    tag: 'HALUCINATION'
  },
  {
    id: '4',
    name: 'CAUTION: DATA OVERFLOW',
    description: 'Too many words, not enough meaning. A commentary on modern AI output.',
    image: 'https://picsum.photos/seed/poorgpt4/1000/800',
    price: '0.005 ETH',
    owner: '0xNode...0001',
    creator: 'TokenMaster',
    tag: 'OVERFLOW'
  },
  {
    id: '5',
    name: 'THE LAST PROMPT',
    description: 'The final words spoken to an AI before it ran out of tokens forever.',
    image: 'https://picsum.photos/seed/poorgpt5/800/800',
    price: '10.0 ETH',
    owner: '0xKing...0000',
    creator: 'PoorGPT_Legacy',
    tag: 'HISTORIC'
  },
  {
    id: '6',
    name: 'BUDGET BOTTLE',
    description: 'A masterpiece created with only 5% of the total available computational power.',
    image: 'https://picsum.photos/seed/poorgpt6/800/800',
    price: '0.002 ETH',
    owner: '0xUser...9999',
    creator: 'LowFiAI',
    tag: 'EFFICIENCY'
  }
];
