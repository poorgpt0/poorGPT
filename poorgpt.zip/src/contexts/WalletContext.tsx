import { createContext, useState, useContext, ReactNode, useEffect } from 'react';

export type WalletType = 'metamask' | 'trustwallet' | 'default';

interface WalletContextType {
  address: string | null;
  balance: string | null;
  connect: (type?: WalletType) => Promise<void>;
  disconnect: () => void;
  error: string | null;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const connect = async (type: WalletType = 'default') => {
    setError(null);
    let provider: any = null;

    // Detect provider based on type
    if (type === 'trustwallet') {
      // Prioritize trustwallet provider if it exists
      provider = (window as any).trustwallet;
      
      // If it's not injected but we have ethereum and it's trust wallet
      if (!provider && (window as any).ethereum?.isTrust) {
        provider = (window as any).ethereum;
      }

      // If we still don't have a Trust Wallet provider
      if (!provider) {
        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        if (isMobile) {
          // Attempt deep link into Trust Wallet app
          const currentUrl = window.location.href;
          window.location.href = `https://link.trustwallet.com/open_url?coin_id=60&url=${encodeURIComponent(currentUrl)}`;
          return;
        } else {
          // If on desktop without Trust Wallet extension, fallback to generic ethereum if available
          provider = (window as any).ethereum;
          if (!provider) {
            setError('Trust Wallet not detected. Please install the Trust Wallet extension.');
            return;
          }
        }
      }
    } else if (type === 'metamask') {
      provider = (window as any).ethereum;
      // Many wallets inject as ethereum, but we can verify isMetaMask if needed. We'll just use the standard one.
      if (!provider) {
        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        if (isMobile) {
          const currentUrl = window.location.href.replace(/^https?:\/\//, '');
          window.location.href = `https://metamask.app.link/dapp/${currentUrl}`;
          return;
        } else {
          setError('MetaMask not detected. Please install the MetaMask extension.');
          return;
        }
      }
    } else {
      provider = (window as any).ethereum;
    }

    if (provider) {
      try {
        // Request account access
        const accounts = await provider.request({ method: 'eth_requestAccounts' });
        
        if (accounts && accounts.length > 0) {
          const account = accounts[0];
          setAddress(`${account.substring(0, 6)}...${account.substring(account.length - 4)}`);
          
          try {
            // Get balance
            const balanceHex = await provider.request({
              method: 'eth_getBalance',
              params: [account, 'latest']
            });
            const ethBalance = parseInt(balanceHex, 16) / 1e18;
            setBalance(`${ethBalance.toFixed(4)} ETH`);
          } catch (e) {
            console.error("Failed to fetch balance", e);
            setBalance('0.0000 ETH');
          }
        }
      } catch (err: any) {
        console.error(err);
        if (err.code === 4001) {
          setError('Connection rejected: Please approve the request in your wallet.');
        } else if (err.code === -32002) {
          setError('Connection pending: Please open your wallet extension/app to approve.');
        } else if (err.message?.toLowerCase().includes('network') || err.code === 4902) {
          setError('Network error: Wrong network selected or network unavailable.');
        } else if (err.message?.toLowerCase().includes('locked')) {
          setError('Wallet locked: Please unlock your wallet and try again.');
        } else {
          setError(err.message || 'An unknown error occurred while connecting the wallet.');
        }
      }
    } else {
      setError('No crypto wallet found. Please install MetaMask or Trust Wallet.');
      // Fallback for demo purposes
      console.log('No ethereum provider found, using fallback demo string.');
      setAddress('0xPoor...1337');
      setBalance('0.005 ETH');
    }
  };

  const disconnect = () => {
    setAddress(null);
    setBalance(null);
    setError(null);
  };

  useEffect(() => {
    const ethereum = (window as any).ethereum;
    if (ethereum) {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length > 0) {
          const account = accounts[0];
          setAddress(`${account.substring(0, 6)}...${account.substring(account.length - 4)}`);
        } else {
          disconnect();
        }
      };

      const handleChainChanged = () => {
        window.location.reload();
      };

      ethereum.on('accountsChanged', handleAccountsChanged);
      ethereum.on('chainChanged', handleChainChanged);

      return () => {
        if (ethereum.removeListener) {
          ethereum.removeListener('accountsChanged', handleAccountsChanged);
          ethereum.removeListener('chainChanged', handleChainChanged);
        }
      };
    }
  }, []);

  return (
    <WalletContext.Provider value={{ address, balance, connect, disconnect, error }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
