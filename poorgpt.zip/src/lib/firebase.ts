// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCCE0m8w4PMlY-T_WEOvjU2nBeMuuzG9JA",
  authDomain: "poorgpt.firebaseapp.com",
  projectId: "poorgpt",
  storageBucket: "poorgpt.firebasestorage.app",
  messagingSenderId: "642618671596",
  appId: "1:642618671596:web:d29ca6b21716130d82c0c9",
  measurementId: "G-3QZF464YTW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const analytics = typeof window !== 'undefined' ? getAnalytics(app) : null;
export const db = getFirestore(app);
export const auth = getAuth(app);
