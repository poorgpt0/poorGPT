import { motion } from 'motion/react';

export default function Drops() {
  return (
    <section className="py-32 px-4 md:px-10 min-h-[70vh] flex flex-col justify-center items-center text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl border border-white/10 bg-card-bg p-12 md:p-24 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-accent/20 blur-3xl rounded-full" />
        <div className="label-caps !opacity-100 text-accent mb-4">SYSTEM NOTIFICATION</div>
        <h1 className="huge-text !text-6xl mb-6">NO ACTIVE DROPS</h1>
        <p className="text-xl opacity-60 mb-12">
          The latent space is currently devoid of sufficient hallucinations for a coherent drop. Please check back when there are more system errors.
        </p>
        
        <div className="inline-block border border-accent p-1 border-dashed">
            <button className="bg-accent text-black px-8 py-4 font-black uppercase text-xl hover:scale-105 active:scale-95 transition-transform cursor-pointer">
              Join Waitlist
            </button>
        </div>
      </motion.div>
    </section>
  );
}
