import NFTGrid from '../components/NFTGrid';

export default function Gallery() {
  return (
    <div className="pt-10">
      <div className="max-w-7xl mx-auto px-4 md:px-10 mb-8">
        <h1 className="huge-text !text-8xl">FULL <span className="text-accent">COLLECTION</span></h1>
      </div>
      <NFTGrid />
    </div>
  );
}
