import { motion } from 'motion/react';
import Hero from '../components/Hero';
import NFTGrid from '../components/NFTGrid';

export default function Home() {
  return (
    <>
      <Hero />
      <NFTGrid />
    </>
  );
}
