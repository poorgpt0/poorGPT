import { motion } from 'motion/react';

export default function Privacy() {
  return (
    <div className="flex-grow flex flex-col justify-center items-center p-10 min-h-[50vh]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl w-full"
      >
        <div className="label-caps !opacity-100 text-accent mb-4">poorgpt.ph // Privacy</div>
        <h1 className="huge-text !text-6xl !leading-none mb-10">Privacy Policy</h1>
        
        <div className="space-y-8 text-white/80 leading-relaxed font-mono">
          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">1. Data Collection</h2>
            <p>At poorgpt.ph, we barely collect data because we can't afford the storage. What we do collect is explicitly tied to your Web3 interactions. Your public wallet address, transaction history on the blockchain, and public assertions are inherently public and permanently recorded on decentralized networks.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">2. Google Authentication</h2>
            <p>If you choose to sign in with Google or any Web2 provider, we only collect your basic profile information (email and profile picture) to facilitate authentication. We do not track your browsing habits, nor do we sell this data to third parties.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">3. Cookies and Tracking</h2>
            <p>We use minimal cookies required for session management and error tracking. There is no cross-site tracking, analytical fingerprinting, or marketing automation running in the background.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">4. Decentralized Truth</h2>
            <p>Remember that interactions with smart contracts are public and irreversible. Once you mint, buy, or interact with a PoorGPT token, that action is inscribed on the blockchain forever. Please operate with opsec in mind.</p>
          </section>

          <p className="border-t border-white/20 pt-8 mt-12 text-sm opacity-50">Last updated: April 2026</p>
        </div>
      </motion.div>
    </div>
  );
}
