import { useWallet } from '../contexts/WalletContext';
import { NFTS } from '../constants';
import NFTCard from '../components/NFTCard';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Zap, X, ExternalLink, Ghost } from 'lucide-react';
import { useState } from 'react';
import { NFT } from '../types';

export default function Profile() {
  const { address, balance } = useWallet();
  const [selectedNFT, setSelectedNFT] = useState<NFT | null>(null);

  if (!address) {
    return (
      <div className="py-32 px-4 md:px-10 min-h-[70vh] flex flex-col justify-center items-center text-center">
        <h1 className="huge-text !text-6xl mb-6 text-white/20">NOT CONNECTED</h1>
        <p className="text-xl opacity-60">Connect your wallet to view your Profile</p>
      </div>
    );
  }

  // Find NFTs owned by the current connected user
  const userNFTs = NFTS.filter(nft => nft.owner === address);

  return (
    <section className="py-24 px-4 md:px-10 max-w-7xl mx-auto min-h-[70vh]">
      <div className="mb-16 border border-white/10 p-8 md:p-12 bg-card-bg flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
           <div className="label-caps !opacity-100 text-accent mb-2">Connected Identity</div>
           <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter breakdown-all">{address}</h1>
        </div>
        <div className="text-right flex-shrink-0">
           <div className="label-caps mb-2">Wallet Balance</div>
           <div className="font-black text-3xl text-accent">{balance}</div>
        </div>
      </div>

      <div className="mb-8 flex justify-between items-end border-b border-white/10 pb-4">
        <h2 className="text-4xl font-black uppercase">Your Collection</h2>
        <div className="label-caps">{userNFTs.length} Assets</div>
      </div>

      {userNFTs.length === 0 ? (
        <div className="py-32 flex flex-col items-center justify-center text-center border border-dashed border-white/20 bg-white/5 relative overflow-hidden group">
          <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Ghost size={64} className="text-accent mb-6 opacity-80 group-hover:scale-110 transition-transform" />
          <h3 className="text-4xl md:text-5xl font-black uppercase tracking-tighter mb-4">No Assets Found</h3>
          <p className="text-lg opacity-60 font-mono uppercase">The latent space is empty here.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {userNFTs.map((nft, i) => (
            <motion.div
              key={nft.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <NFTCard nft={nft} onClick={(nft) => setSelectedNFT(nft)} />
            </motion.div>
          ))}
        </div>
      )}

      {/* Modal Detail View copied from NFTGrid but tailored for profile */}
      <AnimatePresence>
        {selectedNFT && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-12 bg-black/98 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card-bg border border-accent w-full max-w-5xl max-h-full overflow-y-auto flex flex-col md:grid md:grid-cols-2 relative"
            >
              <button 
                onClick={() => setSelectedNFT(null)}
                className="absolute top-8 right-8 z-10 text-white/50 hover:text-accent transition-all cursor-pointer"
              >
                <X size={40} strokeWidth={1} />
              </button>

              <div className="bg-black flex items-center justify-center border-b md:border-b-0 md:border-r border-white/10 p-12">
                <div className="relative group">
                  <img 
                    src={selectedNFT.image} 
                    alt={selectedNFT.name} 
                    className="max-h-[50vh] md:max-h-[60vh] w-auto border border-white/5 shadow-[0_0_50px_rgba(223,255,0,0.1)]"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              <div className="p-8 md:p-12 flex flex-col gap-8 justify-center">
                <div>
                  <div className="label-caps !opacity-100 text-accent mb-4">YOUR ASSET</div>
                  <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter mb-4 leading-none">{selectedNFT.name}</h2>
                  <div className="flex gap-4">
                    <div className="flex items-center gap-2 label-caps">
                      <Zap size={14} className="text-accent" />
                      Poor Network
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-6 py-8 border-y border-white/5">
                  <div>
                    <span className="label-caps block mb-1">Architect</span>
                    <span className="font-bold truncate text-lg">{selectedNFT.creator}</span>
                  </div>
                  <div>
                    <span className="label-caps block mb-1">Acquired Value</span>
                    <span className="font-bold truncate text-xl text-accent">{selectedNFT.price}</span>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <button className="w-full bg-white text-black py-4 font-black text-xl uppercase hover:bg-accent transition-all cursor-pointer">
                    List for Sale
                  </button>
                  <button className="w-full border border-white/20 text-white py-4 font-black text-xl uppercase hover:text-red-500 hover:border-red-500 transition-all cursor-pointer">
                    Burn Asset
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
