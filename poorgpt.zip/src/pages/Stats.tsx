import { motion } from 'motion/react';

export default function Stats() {
  return (
    <section className="py-24 px-4 md:px-10 max-w-7xl mx-auto">
      <div className="mb-16">
        <h1 className="huge-text !text-8xl">NETWORK <span className="text-accent glitch" data-text="STATS">STATS</span></h1>
        <p className="text-xl opacity-60 max-w-lg mt-4">Real-time metrics from the PoorGPT smart contracts and secondary marketplaces.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
        {[
          { label: 'Total Volume', value: '1.2 ETH' },
          { label: 'Floor Price', value: '0.00004 ETH' },
          { label: 'Listed Items', value: '1,492' },
          { label: 'Unique Holders', value: '4' }
        ].map((stat, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="border border-white/10 bg-card-bg p-8"
          >
            <div className="label-caps mb-4 text-accent">{stat.label}</div>
            <div className="text-4xl font-black">{stat.value}</div>
          </motion.div>
        ))}
      </div>

      <div className="border border-white/10 bg-card-bg p-8 md:p-12 h-96 relative overflow-hidden flex flex-col justify-center items-center">
         <div className="absolute inset-x-0 bottom-0 top-1/2 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPgo8cGF0aCBkPSJNMCA1MCBMMjAgNDAgTDQwIDYwIEw2MCAzMCBMODAgNTAgTDEwMCAyMCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjREZGRjAwIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1kYXNoYXJyYXk9IjUgNSIvPgo8L3N2Zz4=')] opacity-20 bg-cover bg-no-repeat" />
         <div className="text-6xl font-black opacity-20">NO RECENT ACTIVITY</div>
      </div>
    </section>
  );
}
