import { motion } from 'motion/react';

export default function Terms() {
  return (
    <div className="flex-grow flex flex-col justify-center items-center p-10 min-h-[50vh]">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl w-full"
      >
        <div className="label-caps !opacity-100 text-accent mb-4">poorgpt.ph // Terms</div>
        <h1 className="huge-text !text-6xl !leading-none mb-10">Terms of Service</h1>
        
        <div className="space-y-8 text-white/80 leading-relaxed font-mono">
          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">1. Acceptance of Terms</h2>
            <p>By accessing poorgpt.ph, you agree to be bound by these Terms of Service. If you do not agree, please do not use the application. These terms are an agreement between you and the void of the latent space.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">2. Artistic Nature</h2>
            <p>PoorGPT is a satirical art project and experimental decentralized gallery. The NFTs (Hallucinations) sold here have ZERO intrinsic financial value, ZERO utility, and NO roadmap. Purchasing them is an act of digital patronage and a celebration of system errors.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">3. Smart Contract Risks</h2>
            <p>You acknowledge that using blockchain technology involves risks, including but not limited to bugs in smart contracts, network failures, and wallet compromises. Poorgpt.ph is not responsible for any lost funds, failed transactions, or unauthorized access to your wallet.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-white mb-4 uppercase">4. No Financial Advice</h2>
            <p>Nothing on poorgpt.ph constitutes financial advice. Do not spend money you cannot afford to lose. The cryptocurrency market is highly volatile, and you solely bear the responsibility for your economic decisions.</p>
          </section>

          <p className="border-t border-white/20 pt-8 mt-12 text-sm opacity-50">Last updated: April 2026</p>
        </div>
      </motion.div>
    </div>
  );
}
