export interface NFT {
  id: string;
  name: string;
  description: string;
  image: string;
  price: string;
  owner: string;
  creator: string;
  tag: string;
}
